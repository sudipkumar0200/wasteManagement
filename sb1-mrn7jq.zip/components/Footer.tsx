"use client";

import { Button } from "@/components/ui/button";
import { Users, Mail, Phone, MapPin } from "lucide-react";

const teamMembers = [
  { name: "Satish Kumar Singh", age: 31, role: "Environmental Engineer", image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80" },
  { name: "Yuvansh Batra", age: 32, role: "Waste Management Specialist", image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80" },
  { name: "Manthan Sidhu", age: 33, role: "Sustainability Consultant", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80" },
];

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-6">Our Team</h3>
            <div className="space-y-4">
              {teamMembers.map((member) => (
                <div key={member.name} className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="font-medium">{member.name}</p>
                    <p className="text-sm opacity-80">{member.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-6">Quick Links</h3>
            <ul className="space-y-2">
              <li className="hover:text-white/80 cursor-pointer">About Us</li>
              <li className="hover:text-white/80 cursor-pointer">Services</li>
              <li className="hover:text-white/80 cursor-pointer">Resources</li>
              <li className="hover:text-white/80 cursor-pointer">Contact</li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-6">Connect With Us</h3>
            <p className="mb-4">Stay updated with our newsletter</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 p-2 rounded-md text-foreground"
              />
              <Button variant="secondary">Subscribe</Button>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-primary-foreground/20 text-center">
          <p>&copy; 2024 Global Waste Management. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}